Read/write and process rs/gis related data, especially atmospheric rs data.


